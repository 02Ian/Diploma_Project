This is the code that accompanies the video here: https://www.youtube.com/watch?v=8aTnmsDMldY

The 'start' directory has the code I started the video with.

The 'finished' directory has the code I ended the video with.